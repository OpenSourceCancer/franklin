/* 09/12/2006		Fuction getNonBlankLine:  Modified for compatibily with gcc 4.1.1
 * 		   	Added #include <stdlib.h> for avoiding various warnings at compilation 
 *
 * 		   	Modificated by: Jose Blanca (jblanca@btc.upv.es) and 
 * 		   		Francisco Gilabert (fragivil@gap.upv.es)
 * The original program can be found at http://espressosoftware.com/pages/sputnik.jsp
 * Sputnik was developed by Chris Abajian at the University of Washington Department
 * of Molecular Biotechnology
*/
/* @(#)sputnik.c	1.22 06/28/01 -*- compile-command: "cc -g sputnik.c"; -*- */
/* #define DEBUG_SPUTNIK 1 */


/*
  find repeats in fasta format seq file 
  allows for indels, returns score.  

  beta version.  caveat emptor.  

  chrisa  29-Jul-94

  chris abajian
  University of Washington
  Dept. of Molecular Biotechnology  FJ-20
  Fluke Hall, Mason Road
  Seattle WA 98195
*/

#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <sys/types.h>

/* trivial defs */
#ifndef True
#define True 1
#endif
#ifndef False
#define False 0
#endif

typedef int Boolean;

/* size of buffer for reads. */ 
#define BUF_SIZE 1024*10   /* 10K */
/* max size of description line (begins with ">") */
#define MAX_DESCRIPTION_LEN 1024
/* sequence is allocated in units of this size. After each sequence is read,
   the allocation is trimmed to the actual size, so this number should be
   fairly large for maximum efficiency */
#define SEQ_ALLOC_UNIT 1024*1024
/* max number of sequence chars dumped to line */
#define MAX_OUT_LINE_CHARS 60

/* for debugging only */
#define MAX_ERRCODES 1

/* search params and definitions */
#define MIN_UNIT_LENGTH 2 /* start search with dinucleotide repeats */
/* will search for di, tri, tetra ... <n>nucleotide repeats up to 
   this value for n */
#define MAX_UNIT_LENGTH 5  /* up to and including pentanucleotides */
/* this is the point score for each exact match */
#define EXACT_MATCH_POINTS 1
/* this is the point score for a mismatch, insertion or deletion */
#define ERROR_MATCH_POINTS -6
/* this is the minimum score required to be considered a match */
#define MATCH_MIN_SCORE 8
/* this is the low score at which we stop trying */
#define MATCH_FAIL_SCORE -1
/* this is the max recursion depth we try to recover errors */
#define MAX_RECURSION 5

int min_unit_length = MIN_UNIT_LENGTH;
int max_unit_length = MAX_UNIT_LENGTH;
int exact_match_points = EXACT_MATCH_POINTS;
int error_match_points = ERROR_MATCH_POINTS;
int match_min_score = MATCH_MIN_SCORE;
int match_fail_score = MATCH_FAIL_SCORE;
int max_recursion = MAX_RECURSION;
int max_out_line_chars = MAX_OUT_LINE_CHARS;
int show_all_headers = 0;
int find_unit_string = 1;
int adjust_scores_1st_uc = 0;
int errs_pph = -1;
int score_is_fidelity = 0;
int recursion_init = 0;
int max_degrade = 1000;
int auto_param = 0;
int min_length = 0;
int output_flanks = 0;
int unit_collapse_rc = 1;

char *repeatName[MAX_UNIT_LENGTH+1] =
{
   "***ERROR***",    /* bad programmer!  no latte! */
   "mononucleotide",
   "dinucleotide",
   "trinucleotide",
   "tetranucleotide",
   "pentanucleotide"
};


char readBuf[BUF_SIZE];
Boolean endOfFile;
int curBufLen;
int curBufPos;
int fd;
Boolean havePutBack;
char putBack;

/* struct for indiv sequence in a file */
typedef struct ss
{
   char descStr[MAX_DESCRIPTION_LEN];
   char *seqStr;
   unsigned int seqLen;
} SeqStruct, *SeqStructPtr;


/*
 * this structure describes the current state of a comparison.
 * it gets passed down to recursive calls of the find repeat
 * call so it can know when to bail out of an unsuccessful
 * search, or return the size/state of a successful hit, etc.
 */
typedef struct ms
{
   int curPos;         /* putative pattern starts here */
   int testPos;        /* start testing here */
   int testLen;        /* di, tri, tetra, etc. */
   int testCtr;        /* # chars in testLen already tested. mod counter */
   int curScore;       /* current score */
   int missense;       /* keep track of ins, del, err */
   int insertions;     
   int deletions;
   int ncount;	       /* Track NNNs */
   int depth;          /* how deep is recursion for this match */
   char errCodes[MAX_ERRCODES];
} MatchStruct, *MatchStructPtr;
/* a utility macro to copy one testStruct to another */
/* #define copyMSPtr(dest,source) memcpy((char *)dest,(char *)source,sizeof(MatchStruct)) */
#define copyMSPtr(dest,source) *(dest)=*(source)
/* a utility macro to increment the modular testCtr */
#define bumpTestCtr(msp) (msp)->testCtr++; if ((msp)->testCtr==(msp)->testLen) (msp)->testCtr=0;


/*
 ************************************************************
 * these routines are used to read and parse the fasta format
 * sequence file
 ************************************************************
 */

void fillBuf()
{
   size_t result;

   result = read(fd, (void *)readBuf, BUF_SIZE);
   if (result == -1)
     {
        fprintf(stderr,"error reading file! errno = %d\n",errno);
        exit(1);
     }
   else if (result == 0)
     endOfFile = True;
   else
     {
        curBufLen = result;
        curBufPos = 0;
     }
}  /* readBuf */


/* returns True on success */
Boolean getChar(char *achar)
{
   if (havePutBack)
     {
        *achar = putBack;
        havePutBack = False;
        return(True);
     }

   if (curBufPos == curBufLen)
     fillBuf();

   if (endOfFile)
     return (False);

   *achar = readBuf[curBufPos++];
   return (True);
}


void putCharBack(char c)
{
   havePutBack = True;
   putBack = c;
}


void openFile(char *fn)
{
   /* open the specified file */
   fd = open(fn, O_RDONLY);
   if (fd == -1)
     {
        fprintf(stderr,"unable to open file %s\n", fn);
        exit(1);
     }
}

/* should call this once for each file read */
void initBuffer()
{
   /* initialize length and pointer */
   curBufPos = 0;
   curBufLen = 0;
   havePutBack = False;
   endOfFile = False;
}

void addCharToLine(char c, char *line, int *lineLen)
{
   if (*lineLen < MAX_DESCRIPTION_LEN)
     line[(*lineLen)++] = c;
}


/*
 *********************************************************************
 * these routines are (more) specific to reading the fasta file format
 *********************************************************************
 */


/* 
 * pick up a non-blank line from the file, presumably description.
 * truncates all leading blanks and/or blank lines 
 */
Boolean getNonBlankLine(char *line)
{
   Boolean stop, nonBlank;
   char c;
   int lineLen;

   lineLen = 0;
   stop = False;
   nonBlank = False;  /* will be set by any non whitespace char */
   while ((! endOfFile) && (! stop))
     if (getChar(&c))
       if (c == '\n')
         stop = nonBlank; /* stop if have anything. don't save eol char. */
       else
         if (nonBlank)
           /* add it to line no matter what */
           addCharToLine(c,line,&lineLen);
         else if ((c != ' ') && (c != '\t'))
           {
              /* only non whitespace will start the line */
              nonBlank = True;
              addCharToLine(c,line,&lineLen);
           }
 
   return(stop);
}


/* load the sequence struct with comment line and bases */
SeqStructPtr getSeq(char *fname) {
    SeqStructPtr newSeqP;
    Boolean endOfSeq;
    char c;
    unsigned int N;

    if (endOfFile) return ((SeqStructPtr )0);   /* bombproofing */

    /* malloc a new seq */
    N = 0;
    newSeqP = (SeqStructPtr )malloc(sizeof(SeqStruct));
    memset(newSeqP, 0, sizeof(SeqStruct));
    newSeqP && (newSeqP->seqStr =
		(char *) malloc(sizeof(char) * SEQ_ALLOC_UNIT));
    N += SEQ_ALLOC_UNIT;
    if (!(newSeqP && newSeqP->seqStr) ) {
        fprintf(stderr,"unable to malloc() memory for sequence.\n");
        exit(1);
    }

    /* pick up description line */
    if (! getNonBlankLine(newSeqP->descStr) ) {
        free(newSeqP->seqStr); free(newSeqP);
        return ((SeqStructPtr )0);   
    }

    /* did it start correctly ? */
    if (newSeqP->descStr[0] != '>') {
        fprintf(stderr,"format error in input file:  missing '>'\n");
        exit(1);
    }

    endOfSeq = False;
    while ((!endOfFile) && (!endOfSeq)) {
	if (newSeqP->seqLen == N) {
	    /* Next character has no space to go. */
	    N += SEQ_ALLOC_UNIT;
	    if (!(newSeqP->seqStr = (char *) realloc(newSeqP->seqStr, N))) {
		fprintf(stderr, "Unable to realloc to %u bytes.\n", N);
		exit(1);
	    }
	}
	 
	if (getChar(&c)) {
	    if (c == '>') {
		/* hit new sequence */
		endOfSeq = True;
		putCharBack(c);
	    } else if ((c = toupper(c)) >= 'A' && (c <= 'Z')) {
		if (c != 'X') {
		    /* Delete XXXs from the input. Assume these are vector
		       masked regions */
		    if (!(c == 'A' || c == 'T' || c == 'G' || c == 'C')) {
			/* Make all ambiguity codes the big one */
			newSeqP->seqStr[newSeqP->seqLen++] = 'N';
		    } else {
			newSeqP->seqStr[newSeqP->seqLen++] = c;
		    }
		}
	    } else if (c == '-' || c == '*') {
		newSeqP->seqStr[newSeqP->seqLen++] = 'N';
	    } else if ((c != '\n') && (c != ' ') && (c != '\t')) {
		/* wierd shit in file.  bail. */
		fprintf(stderr,"bad char in sequence, file %s: %c\n",fname,c);
		exit(1);
	    } 
	}
    }     

    if (! newSeqP->seqLen) {
        fprintf(stderr,"? Null sequence encountered in file %s (ignored)\n",fname);
        fprintf(stderr,"  %s\n", newSeqP->descStr);
        free(newSeqP->seqStr); free(newSeqP);
        return ((SeqStructPtr )0);   
    }

    newSeqP->seqStr = (char *) realloc(newSeqP->seqStr, newSeqP->seqLen);
    return(newSeqP);
}  /* getSeq */


char *unitString(
    int ulen,
    int start,
    int end,
    char *seq
    )
{
    int was = seq[end+1];
    int i, c, mx, imx;
    char *at, **ptr;
    static char *unk = "unk";
    static char *mono[] =
    {
	"A","T",
	"C","G",
	NULL
    };
  
    /* These lists were generated with the ssrCatalog.pl program */
    static char *di[] =
    {
	"AC","GT",
	"AG","CT",
	"AT","AT",
	"CG","CG",
	NULL,
    };
  
    static char *tri[] =
    {
	"AAC","GTT",
	"AAG","CTT",
	"AAT","ATT",
	"ACC","GGT",
	"ACG","CGT",
	"ACT","AGT",
	"AGC","GCT",
	"AGG","CCT",
	"ATC","GAT",
	"CCG","CGG",
	NULL
    };

    static char *tetra[] =
    {
	"AAAC","GTTT",
	"AAAG","CTTT",
	"AAAT","ATTT",
	"AACC","GGTT",
	"AACG","CGTT",
	"AACT","AGTT",
	"AAGC","GCTT",
	"AAGG","CCTT",
	"AAGT","ACTT",
	"AATC","GATT",
	"AATG","CATT",
	"AATT","AATT",
	"ACAG","CTGT",
	"ACAT","ATGT",
	"ACCC","GGGT",
	"ACCG","CGGT",
	"ACCT","AGGT",
	"ACGC","GCGT",
	"ACGG","CCGT",
	"ACGT","ACGT",
	"ACTC","GAGT",
	"ACTG","CAGT",
	"AGAT","ATCT",
	"AGCC","GGCT",
	"AGCG","CGCT",
	"AGCT","AGCT",
	"AGGC","GCCT",
	"AGGG","CCCT",
	"ATCC","GGAT",
	"ATCG","CGAT",
	"ATGC","GCAT",
	"CCCG","CGGG",
	"CCGG","CCGG",
	NULL
    };

    static char *penta[] =
    {
	"AAAAC","GTTTT",
	"AAAAG","CTTTT",
	"AAAAT","ATTTT",
	"AAACC","GGTTT",
	"AAACG","CGTTT",
	"AAACT","AGTTT",
	"AAAGC","GCTTT",
	"AAAGG","CCTTT",
	"AAAGT","ACTTT",
	"AAATC","GATTT",
	"AAATG","CATTT",
	"AAATT","AATTT",
	"AACAC","GTGTT",
	"AACAG","CTGTT",
	"AACAT","ATGTT",
	"AACCC","GGGTT",
	"AACCG","CGGTT",
	"AACCT","AGGTT",
	"AACGC","GCGTT",
	"AACGG","CCGTT",
	"AACGT","ACGTT",
	"AACTC","GAGTT",
	"AACTG","CAGTT",
	"AACTT","AAGTT",
	"AAGAC","GTCTT",
	"AAGAG","CTCTT",
	"AAGAT","ATCTT",
	"AAGCC","GGCTT",
	"AAGCG","CGCTT",
	"AAGCT","AGCTT",
	"AAGGC","GCCTT",
	"AAGGG","CCCTT",
	"AAGGT","ACCTT",
	"AAGTC","GACTT",
	"AAGTG","CACTT",
	"AATAC","GTATT",
	"AATAG","CTATT",
	"AATAT","ATATT",
	"AATCC","GGATT",
	"AATCG","CGATT",
	"AATCT","AGATT",
	"AATGC","GCATT",
	"AATGG","CCATT",
	"AATGT","ACATT",
	"AATTC","GAATT",
	"ACACC","GGTGT",
	"ACACG","CGTGT",
	"ACACT","AGTGT",
	"ACAGC","GCTGT",
	"ACAGG","CCTGT",
	"ACAGT","ACTGT",
	"ACATC","GATGT",
	"ACATG","CATGT",
	"ACCAG","CTGGT",
	"ACCAT","ATGGT",
	"ACCCC","GGGGT",
	"ACCCG","CGGGT",
	"ACCCT","AGGGT",
	"ACCGC","GCGGT",
	"ACCGG","CCGGT",
	"ACCGT","ACGGT",
	"ACCTC","GAGGT",
	"ACCTG","CAGGT",
	"ACGAG","CTCGT",
	"ACGAT","ATCGT",
	"ACGCC","GGCGT",
	"ACGCG","CGCGT",
	"ACGCT","AGCGT",
	"ACGGC","GCCGT",
	"ACGGG","CCCGT",
	"ACGTC","GACGT",
	"ACTAG","CTAGT",
	"ACTAT","ATAGT",
	"ACTCC","GGAGT",
	"ACTCG","CGAGT",
	"ACTCT","AGAGT",
	"ACTGC","GCAGT",
	"ACTGG","CCAGT",
	"AGAGC","GCTCT",
	"AGAGG","CCTCT",
	"AGATC","GATCT",
	"AGATG","CATCT",
	"AGCAT","ATGCT",
	"AGCCC","GGGCT",
	"AGCCG","CGGCT",
	"AGCCT","AGGCT",
	"AGCGC","GCGCT",
	"AGCGG","CCGCT",
	"AGCTC","GAGCT",
	"AGGAT","ATCCT",
	"AGGCC","GGCCT",
	"AGGCG","CGCCT",
	"AGGGC","GCCCT",
	"AGGGG","CCCCT",
	"ATATC","GATAT",
	"ATCCC","GGGAT",
	"ATCCG","CGGAT",
	"ATCGC","GCGAT",
	"ATGCC","GGCAT",
	"CCCCG","CGGGG",
	"CCCGG","CCGGG",
	"CCGCG","CGCGG",
	NULL
    };

    switch (ulen) {
    case 1: ptr = mono; break;
    case 2: ptr = di; break;
    case 3: ptr = tri; break;
    case 4: ptr = tetra; break;
    case 5: ptr = penta; break;
    default:
	fprintf(stderr, "INTERNAL error. We handle only up to penta\n");
	exit(3);
    }

    seq[end+1] = 0;
  
    mx = 0;
    imx = -1;
    for (i = 0; 1; i++) {
	if (!ptr[i]) break;
	at = &seq[start];
	c = 0;
	while (at = strstr(at, ptr[i])) {
	    c++;
	    at += ulen;
	}
	if (c > mx) {
	    mx = c;
	    imx = i;
	}
    }
  
    seq[end+1] = was;
    if (imx > -1) {
	if (unit_collapse_rc) imx = imx / 2 * 2;
	return ptr[imx];
    } else {
	return unk;
    }
}


/* for debugging.  dump entire seq to stdout. */
#ifdef DEBUG_SPUTNIK
void dumpSeq(SeqStructPtr seqP)
{
   int i, charsOnLine;

   fprintf(stdout,"%s\n", seqP->descStr);
   fprintf(stdout,"Sequence (length = %u):\n", seqP->seqLen);
   i = 0;
   charsOnLine = 0;
   while (i < seqP->seqLen)
     {
        if (charsOnLine == max_out_line_chars)
          {
             fprintf(stdout,"\n");
             charsOnLine = 1;
          }
        else
          charsOnLine++;
        fprintf(stdout,"%c", seqP->seqStr[i++]);
     } 
   fprintf(stdout,"\n");
} /* dumpSeq */
#endif /* DEBUG_SPUTNIK */

/* dump the matched seq & stats to stdout */
void dumpMatch(SeqStructPtr seqP, 
               MatchStructPtr matchP,
               Boolean anyMatchThisSeq)
{
   int i, j, charsOnLine;
   int score, adjLen;
   int trim;
   char *unit_str;
   char *ptr1, *ptr2;

   if (! anyMatchThisSeq)
     fprintf(stdout,"%s\n", seqP->descStr);

   /* Make sure length of repeat is a multiple of the unit size. If it
    * is not, it should be trimmed back -- we know that extending it does
    * not improve the score, so that option need not be explored.
    */
   adjLen = matchP->testPos - matchP->curPos -
       matchP->insertions + matchP->deletions;
   if (matchP->testLen > 1 &&
       (trim = adjLen % matchP->testLen) != 0) {
       matchP->testPos -= trim;
       adjLen -= trim;

       /* This is not rigorous, but if exact_match_points * unit_len - 2
	* is < abs(penalty_points), then a fractional unit cell will be
	* entirely made up of matches, and then this is correct. The
	* loop just excludes uncounting NNNs */
       ptr1 = &seqP->seqStr[matchP->curPos];
       ptr2 = &seqP->seqStr[matchP->testPos];
       for (i = 0; i < trim; i++) {
	   if (*(ptr1++) == *(ptr2++)) matchP->curScore -= exact_match_points;
       }
   }
       
   if (score_is_fidelity) {
       /* Report score as percent of bases that are not errors or Ns */
       score = 
	   (adjLen -
	    (matchP->missense + matchP->insertions + matchP->deletions +
	     matchP->ncount)) * 100 / adjLen;
   } else {
       score = matchP->curScore;
   }
   
   if (find_unit_string) {
     unit_str = unitString(matchP->testLen, matchP->curPos, matchP->testPos-1,
			   seqP->seqStr);
     fprintf(stdout,"%s %d : %d -- length %d score %d unit %s\n",
	     repeatName[matchP->testLen], 
	     matchP->curPos+1,
	     matchP->testPos,
	     adjLen,
	     score,
	     unit_str);
   } else {
     fprintf(stdout,"%s %d : %d -- length %d score %d\n",
	     repeatName[matchP->testLen], 
	     matchP->curPos+1,
	     matchP->testPos,
	     adjLen,
	     score);
     unit_str = "notdetermined";
   }
   
#ifdef DEBUG_SPUTNIK
   fprintf(stdout,"mis = %d, del = %d, ins = %d\n", 
           matchP->missense,
           matchP->deletions,
           matchP->insertions);
#endif

   if (output_flanks > 0) {
       int j;
       
       i = matchP->curPos - output_flanks;
       if (i < 0) i = 0;
       j = matchP->testPos + output_flanks;
       if (j > seqP->seqLen) j = seqP->seqLen;
       
       for (; i < matchP->curPos; i++) putchar(seqP->seqStr[i]);
       putchar(':');
       for (; i < matchP->testPos; i++) putchar(seqP->seqStr[i]);
       putchar(':');
       for (; i < j; i++) putchar(seqP->seqStr[i]);
       putchar('\n');
   } else if (max_out_line_chars != 0) {
       i = matchP->curPos;
       charsOnLine = 0;
       while (i < matchP->testPos) {
	   if (charsOnLine == max_out_line_chars) {
	       fprintf(stdout,"\n");
	       charsOnLine = 1;
	   }
	   else charsOnLine++;
	   fprintf(stdout,"%c", seqP->seqStr[i++]);
       } 
       fprintf(stdout,"\n");
   }
   
#ifdef DEBUG_SPUTNIK
   i = 0;
   charsOnLine = 0;
   while (i < (matchP->testPos - matchP->curPos))
     {
        if (charsOnLine == max_out_line_chars)
          {
             fprintf(stdout,"\n");
             charsOnLine = 1;
          }
        else
          charsOnLine++;
        if (matchP->errCodes[i] == '\0')
          fprintf(stdout," ");
        else
          fprintf(stdout,"%c", matchP->errCodes[i]);
        i++;
     } 
   fprintf(stdout,"\n");
#endif
}  /* dumpMatch */


Boolean testForNRepeat(SeqStructPtr seqP,
                       MatchStructPtr matchP)
{
   MatchStruct curMatch, recover, bestSoFar, bestOfABadLot;

   /* save matchP in case we fail altogether. */
   copyMSPtr(&curMatch, matchP);
   /* keep track of the best score and return that if over thresh. */
   copyMSPtr(&bestSoFar, matchP);

   while ( (curMatch.testPos < seqP->seqLen)           /* anything to test */
          && (curMatch.curScore > match_fail_score)
	  && (curMatch.curScore >
	      bestSoFar.curScore + error_match_points * max_degrade))
       /* above fail threshold */
     {
        /* test a base */
        if (seqP->seqStr[curMatch.curPos+curMatch.testCtr] 
            == seqP->seqStr[curMatch.testPos])
          {
             /* we matched.  this is easy. */
             curMatch.curScore += exact_match_points;  /* score your points */
             curMatch.testPos++; /* advance the downstream test position */
             bumpTestCtr(&curMatch); /* advance pos in the (presumed) repeating seq */
          }
        else if (seqP->seqStr[curMatch.testPos] == 'N' && max_recursion > 0)
          {
             /* don't call it wrong, but no credit either */
             curMatch.testPos++; /* advance the downstream test position */
	     curMatch.ncount++;
             bumpTestCtr(&curMatch); /* advance pos in the (presumed) repeating seq */
          }
        else
          {
             /* no match.  take the score penalty, but keep going (maybe). */
             curMatch.curScore += error_match_points;
             curMatch.testPos++; /* advance the downstream test position */
             bumpTestCtr(&curMatch);  /* advance pos in seq */
             /* is the score too bad to continue, or are we
                already too deep? */
             if ( (curMatch.curScore >
		   match_fail_score + recursion_init * curMatch.testLen)
                  && (curMatch.depth < max_recursion) )
               {
                  /* try simple missense */
                  copyMSPtr(&recover,&curMatch);
                  if ((recover.testPos - recover.curPos) < MAX_ERRCODES)
                    recover.errCodes[recover.testPos - recover.curPos -1] = 'M';
                  recover.missense++;
                  recover.depth++;
                  (void )testForNRepeat(seqP,&recover);
                  copyMSPtr(&bestOfABadLot,&recover);

                  /* try deletion */
                  copyMSPtr(&recover,&curMatch);
                  if ((recover.testPos - recover.curPos) < MAX_ERRCODES)
                    recover.errCodes[recover.testPos - recover.curPos -1] = 'D';
                  recover.testPos--; /* DON'T advance downstream */
                  recover.deletions++;
                  recover.depth++;
                  (void )testForNRepeat(seqP,&recover);
                  if (recover.curScore > bestOfABadLot.curScore)
                    copyMSPtr(&bestOfABadLot,&recover);

                  /* try insertion */
                  copyMSPtr(&recover,&curMatch);
                  if ((recover.testPos - recover.curPos) < MAX_ERRCODES)
                    recover.errCodes[recover.testPos - recover.curPos -1] = 'I';
                  /* RETEST for this base in the repeating seq */
                  if (recover.testCtr == 0)
                    recover.testCtr = recover.testLen - 1;
                  else
                    recover.testCtr--;
                  recover.insertions++;
                  recover.depth++;
                  (void )testForNRepeat(seqP,&recover);
                  if (recover.curScore > bestOfABadLot.curScore)
                    copyMSPtr(&bestOfABadLot,&recover);

                  /* take the best of a bad lot */
                  bestOfABadLot.depth--;  /* dec recursion counter */ 
                  copyMSPtr(&curMatch, &bestOfABadLot);
               }  /* it was worth carrying on */
          }  /* no match, found best of bad lot */

        /* whatever happened, the best we could do is now in matchP */
        if (curMatch.curScore > bestSoFar.curScore)
          copyMSPtr(&bestSoFar, &curMatch);

     }  /* while loop to test a single base */

   /* for whatever reason, we've stopped searching for more of this
      putative repeat.  if there were any matches that passed
      the global threshold, return the best of them. note that this
      has the effect of NOT advancing the pointer(s) if nothing
      rang the bell.  remember that we will test the same position
      for ntide repeats of several different lengths. */
   if (bestSoFar.curScore > match_min_score)
     {
        copyMSPtr(matchP, &bestSoFar);
        return(True);
     }
   return(False);   /* the whole thing was a waste of time */
}  /* testForNRepeat */


/* 
 * returns True if the sequence we want to look for repeats of is
 *
 * a) all the same base (i.e. 'AAA' or 'GG').  This filters out
 *    single nucleotide repeats
 *
 * b) conains 'N'.  we search against these, but don't use them
 *    as wildcards.
 */
Boolean ignoreSeq(SeqStructPtr seqP,
                  MatchStructPtr matchP)
{
   int i;

   /* firstly, never search for any pattern that contains N */
   for (i = 0; i < matchP->testLen; i++)
     if (seqP->seqStr[matchP->curPos+i] == 'N')
       return(True);

   /* now test for mononucleotide repeat.  other tests may get 
      added, in which case this one will beed to be changed. */
   if (matchP->testLen == 1) {
       /* We are specifically looking for mono-repeats */
       return(False);
   }
   for (i = 1; i < matchP->testLen; i++)
      if (seqP->seqStr[matchP->curPos] != seqP->seqStr[matchP->curPos+i])
        return(False);  /* they're not all the same */
   return (True);  /* they ARE all same */
}


void findRepeats(SeqStructPtr seqP)
{
   int curPos;
   int maxErrs;
   Boolean anyMatchThisSeq, matchAtThisPos;
   MatchStruct match;

   memset( (char *)&match, 0, sizeof(MatchStruct) );  /* clear match struct */

   anyMatchThisSeq = False; /* avoid dumping description more than once. */
   /* loop on all positions in the sequence.  note that a match
      will advance curPos past all matching chars to the first
      unmatched char. */
   while ( match.curPos <= seqP->seqLen)
     {
        /* now loop on all the different lengths of repeats we're
           looking for (i.e. di, tri, tetra nucleotides.  if we
           find a match at a shorter repeat length, forego testing
           for longer lengths. */
        match.testLen = min_unit_length;
        matchAtThisPos = False;
        while ((match.testLen <= max_unit_length) && (!matchAtThisPos))
          {
             /* initialize the state of the match */
	     if (auto_param) {
		 if (match.testLen < 3) {
		     max_recursion = 1;
		 } else {
		     max_recursion = 2;
		 }
		 adjust_scores_1st_uc = 1;
	     }
	     if (adjust_scores_1st_uc) {
		 /* If there is a match, the 1st unit cell is not counted,
		    but logically it should be. */
		 match.curScore = exact_match_points * match.testLen;
	     } else {
		 match.curScore = 0;  /* no points yet */
	     }
             match.testCtr = 0; /* no chars tested yet */
             match.testPos = match.curPos + match.testLen;
             match.insertions = 0;
             match.deletions = 0;
             match.missense = 0;
	     match.ncount = 0;
             /* there are some things we don't want to test for */
             if (! ignoreSeq(seqP,&match)) {
		 matchAtThisPos = testForNRepeat(seqP, &match);
		 if (matchAtThisPos && errs_pph >= 0) {
		     /* The number of errors cannot exceed the metric
			based on length */
		     maxErrs = 
		       ((match.testPos - match.curPos) * errs_pph + 50)/ 100;
		     if (match.insertions + match.deletions +
			 match.missense + match.ncount > maxErrs) {
			 matchAtThisPos = False;
		     }
		 }
	     } else {
	       matchAtThisPos = False;
	     }

             if (! matchAtThisPos) match.testLen++;
          }

        if (matchAtThisPos)
          {
	      if (match.testPos - match.curPos >= min_length) {
		  dumpMatch(seqP,&match,anyMatchThisSeq);
		  anyMatchThisSeq |= matchAtThisPos;
	      }
             match.curPos = match.testPos;
          }
        else
          match.curPos++;  /* no, so advance to next base. */
     }

   if (!anyMatchThisSeq && show_all_headers) {
     /* No matches, and our output is supposed to have something for each
	input sequence */
     fprintf(stdout,
	     "%s\n"
	     "zeronucleotide 0 : 0 -- length 0 score 0%s\n",
	     seqP->descStr,
	     find_unit_string ? " unit none" : "");
   }
}

 

main(int argc, char* argv[])
{
  extern char *optarg;
  extern int optind, opterr, optopt;

   SeqStructPtr seqP;
   int count;
   int errs = 0;
   char c;

   while ((c = getopt(argc, argv, "hAajpxzd:u:v:m:n:s:e:f:r:F:R:l:L:")) != EOF) {
     switch (c) {
     case 'z':
	 unit_collapse_rc = 0;
	 break;
     case 'A':
	 auto_param = 1;
	 break;
     case 'F':
	 output_flanks = atoi(optarg);
	 if (output_flanks < 0 || output_flanks > 1000) {
	     errs++;
	 }
	 break;
     case 'u':
       max_unit_length = atoi(optarg);
       if (max_unit_length > 5 || max_unit_length < 1) {
	 errs++;
       }
       break;
     case 'v':
       min_unit_length = atoi(optarg);
       if (min_unit_length > 5 || min_unit_length < 1) {
	 errs++;
       }
       break;
     case 'm':
       exact_match_points = atoi(optarg);
       if (exact_match_points < 1) {
	 errs++;
       }
       break;
     case 'n':
       error_match_points = atoi(optarg);
       if (error_match_points > -1) {
	 errs++;
       }
       break;
     case 's':
       match_min_score = atoi(optarg);
       if (match_min_score < 1) {
	 errs++;
       }
       break;
     case 'e':
       errs_pph = atoi(optarg);
       if (errs_pph > 100) {
	 errs++;
       }
       break;
     case 'f':
       match_fail_score = atoi(optarg);
       if (match_fail_score > -1) {
	 errs++;
       }
       break;
     case 'd':
       max_degrade = atoi(optarg);
       if (max_degrade < 1) {
	 errs++;
       }
       break;
     case 'r':
       max_recursion = atoi(optarg);
       if (max_recursion < 0) {
	 errs++;
       }
       break;
     case 'R':
       max_recursion = atoi(optarg);
       if (max_recursion < 0) {
	 errs++;
       }
       recursion_init = 1;
       break;
     case 'l':
       max_out_line_chars = atoi(optarg);
       if (max_out_line_chars < -1) {
	 errs++;
       }
       break;
     case 'L':
       min_length = atoi(optarg);
       if (min_length < 0) {
	 errs++;
       }
       break;
     case 'a':
       show_all_headers = 1;
       break;
     case 'j':
       adjust_scores_1st_uc = 1;
       break;
     case 'p':
       score_is_fidelity = 1;
       break;
     case 'x':
       find_unit_string = 0;
       break;
     case 'h':
       errs++;
       break;
     case '?':
       errs++;
       break;
     }
   }

   if (min_unit_length > max_unit_length) {
       errs++;
   }

   if (recursion_init) {
       /* Require the score be at least one unit cell good */
       recursion_init = exact_match_points;
       if (adjust_scores_1st_uc) {
	   /* If the score includeds the 1st uc, it needs to be 2 cells good */
	   recursion_init *= 2;
       }
   }

   if (max_recursion == 0) {
       /* We are only interested in perfect repeats, so the mismatch score
	* must be a big negative */
       error_match_points = -60000;
   }
   
   if (errs || argc != optind + 1) {
     fprintf(stderr,"Usage: %s -umnsfr _fasta_file\n"
	     "where:\n"
	     "-a      show all (even when there is no repeat)\n"
	     "-x      dont bother finding the canonical repeat unit\n"
	     "-u int  max unit length [-v, 5]\n"
	     "-v int  min unit length [1, -u]\n"
	     "-m int  points for a match [1,)\n"
	     "-n int  points for a mis-match (,-1]\n"
	     "-s int  min score [5,)\n"
	     "-j      adjust scores for the first unit cell.\n"
	     "-e int  errors per 100 bases, -ve means ignore [-1,100].\n"
	     "-p      report score as percent perfection.\n"
	     "-f int  fail score (,-1]\n"
	     "-d int  max degrade and still continue, in bases.\n"
	     "-r int  max recursion [0, 100] (0 ==> perfect only)\n"
	     "-R int  max recursion [0, 100], and do recursions only if\n"
	     "        score is at least unit length times score for a match.\n"
	     "        Zero implies only perfect repeats will be found.\n"
	     "-A      set -r automatically (by unit cell), and set -j.\n"
	     "-F int  output this many bases flanking the repeat [0, 1000].\n"
	     "-L int  min length of SSR to report.\n"
	     "-l int  max chars on an output line [-1,).\n"
	     "        -1 means no limit, or one line no matter how long \n"
	     "        0 means dont output the repeat sequence at all\n"
	     "-z      do not collapse unit cell to canonical strand\n",
	     argv[0]);
     exit(2);
   }
       

   openFile(argv[optind]);

   initBuffer();

   count = 0;
   while (! endOfFile) 
     if (seqP = getSeq(argv[1]))
       {
#ifdef DEBUG_SPUTNIK
          fprintf(stdout,"processing sequence %d\n", count++);
#endif
          /* dumpSeq(seqP); */
          findRepeats(seqP);
          free(seqP->seqStr); free(seqP);
       }
   exit(0);
}
