
franklin
========

franklin is a bioinformatic application created to work on sequence analysis by using NGS (Next Generation Sequencing) and sanger sequences. It is capable of cleaning reads, do de novo assembly or mapping against a reference and annotate SNPs, SSRs, ORFs, GO terms and sequence descriptions.

You can find more documentation in the doc directory.
